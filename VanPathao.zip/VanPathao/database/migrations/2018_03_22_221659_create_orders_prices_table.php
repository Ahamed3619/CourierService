<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersPricesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders_prices', function (Blueprint $table) {
            $table->increments('id');
            $table->string('orderId',150);
            $table->float('productWeight',10,2);
            $table->float('productHeight',10,2);
            $table->float('productWidth',10,2);
            $table->integer('TotalPrice');
            $table->string('payMethod',150);
            $table->string('ShipmentStatus')->default("On The Way");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders_prices');
    }
}
