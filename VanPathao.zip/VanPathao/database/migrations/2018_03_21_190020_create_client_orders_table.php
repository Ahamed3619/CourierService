<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('client_orders', function (Blueprint $table) {
            $table->increments('id');
            $table->string('senderName');
            $table->integer('senderPhone');
            $table->string('senderEmail');
            $table->text('senderAddress');
            $table->string('senderDivision');
            $table->string('senderCity');

            $table->string('receiverName');
            $table->integer('receiverPhone');
            $table->text('receiverAddress');
            $table->string('receiverDivision');
            $table->string('receiverCity');

            $table->string('productName');
            $table->integer('orderQuantity');
            $table->string('orderCompany');
            $table->string('conditionAgree');
            $table->text('orderStatus')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('client_orders');
    }
}
