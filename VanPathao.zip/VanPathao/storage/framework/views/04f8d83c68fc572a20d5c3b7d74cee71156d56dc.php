<!-- Contact-us Div start -->
<div class="contact-us">
    <div class="container">

        <h2 class="contact-title"><hr><br> Contact-<strong>Us</strong> </h2>
        <hr><br><br>
        <div class="col-lg-6 col-sm-12 col-md-12">
            <div id="Contact-details">
                <div class="Contact-place">
                    <h3>DHAKA :</h3><br>
                    <h3>SYLHET :</h3><br>
                    <h3>KHULNA :</h3><br>
                    <h3>BARISAL :</h3><br>
                    <h3>RAJSHAHI :</h3><br>
                    <h3>CHITTAGONG :</h3><br>
                </div>
                <div class="Contact-number">
                    <h3>+8801756576638</h3><br>
                    <h3>+8801656546638</h3><br>
                    <h3>+8801756576638</h3><br>
                    <h3>+8801956576678</h3><br>
                    <h3>+8801859576638</h3><br>
                    <h3>+8801756586938</h3><br>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-sm-12 col-md-12">

            <div id="Contact-message">
                <h1 class="text-center text-success" ><?php echo e(Session::get('message')); ?></h1>
                <div class="client-info">
                    <h5>NAME :</h5>
                    <h5>EMAIL :</h5>
                    <h5>PHONE :</h5>
                    <h5>MESSAGE :</h5>
                </div>
                <div class="client-input">

                    <?php echo e(Form::open(['route'=>'clientMessage','class'=>'contact-form','method'=>'POST','enctype'=>'multipart/data'])); ?>

                        <input type="text" name="contactName" pattern="[a-zA-Z]{3,20}[a-zA-Z\s]*" required placeholder="Your-Name" title="Name should only contain letters">
                        <input type="email" name="contactEmail"  title="Enter Valid Email e.g:example@mail.com" placeholder="Your-Email" required>
                        <input type="text" required pattern="[01]{2}[0-9]{9}" name="contactPhone" placeholder="Your- Phone" title="Enter Valid Phone Number e.g:01756576638"/>
                        <textarea type="text" rows="4" name="comment" id="confirmationText" class="form-control" placeholder="Your-Message" style="border-radius: 0;"></textarea>
                        <input type="submit" value="SEND">
                    <?php echo e(Form::close()); ?>




                </div>
            </div>
        </div>

    </div>
</div><!--Contact us div End-->