<?php $__env->startSection('title'); ?>
    Add a New Courier
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="row" xmlns="http://www.w3.org/1999/html">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Enter Shipment Status</h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <?php echo e(Form::open(['route'=>'shipment-status', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])); ?>


                    <div class="form-group">
                        <label class="control-label col-md-4">Order ID</label>
                        <div class="col-md-8">
                            <input type="text" name="orderId" class="form-control" value="<?php echo e($orderId); ?>">
                            <span class="text-danger"><?php echo e($errors->has('orderId') ? $errors->first('orderId') : ''); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Shipment Status</label>
                        <div class="col-md-8">
                            <input type="text" name="ShipmentStatus" class="form-control">
                            <span class="text-danger"><?php echo e($errors->has('ShipmentStatus') ? $errors->first('ShipmentStatus') : ''); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save">
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>