<?php if(Session::get('clienEmail')): ?>


    <ul class="list-inline" id="profiles" >
        <li class="dropdown" >
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i>Welcome <?php echo e($checklogin->name); ?> <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user" >
                <li><a href="<?php echo e(route('userProfile')); ?>"><i class="fa fa-user fa-fw"></i> Profile</a>
                </li>
                <li><a href="<?php echo e(route('changePassword')); ?>"><i class="fa fa-gear fa-fw"></i> Settings</a>
                </li>
                <li class="divider"></li>
                <li><a href="<?php echo e(route('clientLogout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">

                        <i class="fa fa-sign-out fa-fw"></i> Logout

                    </a>
                    <form id="logout-form" action="<?php echo e(route('clientLogout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
    </ul>




<?php else: ?>
    <?php echo $__env->make('front-end.includes.signin-signupButton', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>



