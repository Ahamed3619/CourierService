<?php $__env->startSection('signinSignup'); ?>
    <?php echo $__env->make('front-end.includes.loginChecker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div id="user-background">
        <div class="container">
            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked well">
                    <li><a href="<?php echo e(route('/')); ?>"><i class="fa fa-home"></i> Home</a></li>
                    <li class="<?php echo e(request()->is('Courier/User-Profile') ? 'active' : ''); ?>"><a href="<?php echo e(route('userProfile')); ?>"><i class="fa fa-user"></i> Profile</a></li>
                    <li class="<?php echo e(request()->is('Courier/User-Settings') ? 'active' : ''); ?>"><a href="<?php echo e(route('changePassword')); ?>"><i class="fa fa-key"></i> Change Password</a></li>
                    <li class="<?php echo e(request()->is('Courier/Edit-Profile') ? 'active' : ''); ?>"><a href="<?php echo e(route('editProfile')); ?>"><i class="glyphicon glyphicon-edit"></i> Edit Profile</a></li>
                    <li><a href="<?php echo e(route('clientLogout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">

                            <i class="fa fa-sign-out fa-fw"></i> Logout

                        </a>
                        <form id="logout-form" action="<?php echo e(route('clientLogout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="panel">
                    <div class="name"><small><?php echo e($checklogin->name); ?> Profile</small></div>

                    <?php if($checklogin->userImage): ?>
                        <img class="pic img-circle" src="<?php echo e(asset($checklogin->userImage)); ?>" alt="..." style="height: 150px;width: 150px">
                    <?php else: ?>
                    <img class="pic img-circle" src="http://placehold.it/150x150" alt="...">
                    <?php endif; ?>
                    <a href="#"  style="text-decoration: none;">
                        <?php echo e(Form::open(['route'=>'userImage', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data','accept'=>'image/*'])); ?>



                        <label for="inputfile" class="btn btn-xs btn-primary" style=" margin:10px 0px 0px 38px; ">
                            <span class="glyphicon glyphicon-picture" aria-hidden="true"></span>
                            Image
                            <input type="file" name='inputfile' id='inputfile' style="display:none">
                        </label>
                        <button type="submit" class="btn btn-xs btn-danger"  style=" margin-top:10px; ">Upload</button>
                        <?php echo e(Form::close()); ?>

                    </a>

                </div>

                <br><br><br>
                <?php echo $__env->yieldContent('content'); ?>


            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>