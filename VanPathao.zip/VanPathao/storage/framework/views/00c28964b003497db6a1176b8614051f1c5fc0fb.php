
<!-- Menu Bar Start -->

<div class="search-background"><!-- background-side start  -->
    <nav class="second-navbar"><!-- second-navbar start  -->
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" id="title" href="<?php echo e(route('/')); ?>"><i class="fa fa-truck" aria-hidden="true"></i>Courier BD</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('/')); ?>">Home</a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('companies') ? 'active' : ''); ?>" href="<?php echo e(route('companies')); ?>">Companies</a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('order') ? 'active' : ''); ?>" href="<?php echo e(route('order')); ?>">Order</a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">About Us</a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('price') ? 'active' : ''); ?>" href="<?php echo e(route('price')); ?>">Price</a>
                    </li>
                    <li>
                        <a class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav><!-- second-navbar end  -->
    <h3 class="trust">Search ...</h3>

</div><!-- background-side end  -->

<!-- Menu Bar end -->

