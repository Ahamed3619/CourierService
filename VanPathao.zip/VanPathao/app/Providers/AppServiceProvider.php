<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Session;
use View;
use App\Company;
use App\Client;
use App\ClientOrder;
use DB;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //for single view file data pass
        View::composer('front-end.includes.homeBody', function ($view){
                $view->with('myCompany',Company::where('publication_status',1)
                ->orderBy('id', 'asc')
                ->get());
        });
        View::composer('front-end.includes.orderContent', function ($view){
                $view->with('myCompany',Company::where('publication_status',1)
                ->orderBy('id', 'asc')
                ->get());
        });
        View::composer('front-end.companies.companies', function ($view){
                $view->with('myCompany',Company::where('publication_status',1)
                ->orderBy('id', 'asc')
                ->get());
        });
        View::composer('front-end.master', function ($view){
                $view->with('checklogin',DB::table('clients')
                    ->where(['email'=>Session::get('clienEmail')])
                    ->first());
        });

        View::composer('front-end.includes.loginChecker', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });
        View::composer('front-end.client.clientLoggedin', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });

        View::composer('front-end.client.userProfile', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });
        View::composer('front-end.client.profileContent', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });
        View::composer('front-end.client.editProfile', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });
        View::composer('front-end.includes.orderContent', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });
        View::composer('front-end.orderPrice.orderSubmitted', function ($view){
            $view->with('checklogin',DB::table('clients')
                ->where(['email'=>Session::get('clienEmail')])
                ->first());
        });

        View::composer('front-end.client.userProfile', function ($view){
            $view->with('myOrder',ClientOrder::where('senderEmail',Session::get('clienEmail'))
                ->orderBy('id', 'desc')
                ->paginate('5'));
        });

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
