<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Client;
use Illuminate\Support\Facades\Session;
use Auth;
use DB;
use Hash;
use Image;
class ClientController extends Controller
{
    public function clientLogin(Request $request){
        $this->validate($request,[
            'email'=>'required',
            'password'=>'required'
        ]);
        $checklogin = DB::table('clients')
            ->where(['email'=>$request->email,'password'=>md5($request->password)])
            ->first();
        if ( count($checklogin) >0 ){

                Session::put('clienEmail', $request->email);
                return view("front-end.client.clientLoggedin", ['checklogin' => $checklogin]);

        }
        else{

            return redirect('/')->with('message','Email or Password Incorrect');
        }

    }

    public function clientSignup(Request $request){
        $myClient=new Client();

        $this->validate($request,[
            'name'=>'required|string|max:255',
            'email'=>'required|string|email|max:255|unique:clients',
            'password'=>'required|string|min:6|confirmed'
        ]);

        $myClient->name=$request->name;
        $myClient->email=$request->email;
        $myClient->password= md5($request->password);
        $myClient->save();
        Session::put('clientId',$myClient->id);
        Session::put('clienEmail',$myClient->email);
        Session::put('clientPW',$myClient->password);
        return view("front-end.client.clientLoggedin");
    }
    public function userProfile(){
        return view("front-end.client.userProfile");

    }
    public function clientLogout(){
        Session::forget('clienEmail');
        return redirect('/');

    }
    public function changePassword(){

    return view('front-end.client.editPassword');
    }
    public function editProfile(){

    return view('front-end.client.editProfile');

    }
    public function clientUpdate(Request $request){
//        $sessionEmail=Session::get('clienEmail');
//        $myClient = DB::table('clients')
//            ->where(['email'=>$sessionEmail])
//            ->first();
        $this->validate($request,[
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'address'=>'required'
        ]);
        DB::table('clients')
            ->where('email', Session::get('clienEmail'))
            ->update(['name' => $request->name,'email'=>$request->email,'phone'=>$request->phone,'address'=>$request->address]);
        Session::put('clienEmail',$request->email);
        return redirect('Courier/User-Profile');
    }
    public function passwordUpdate(Request $request){
        $this->validate($request,[
            'password'=>'required|string|min:6|confirmed'
        ]);
        DB::table('clients')
            ->where('email', Session::get('clienEmail'))
            ->update(['password' => md5($request->password)]);
        return redirect('Courier/User-Settings')->with('message','Successfully Password Changed');

    }
    public function userImage(Request $request){
        $myImage=$request->file('inputfile'); //for image upload we need use file('input field name')
        if ($myImage){

            $imageName=$myImage->getClientOriginalName(); //name of the image (control+space) for the function
            $directory='clientImages/';//directory or path create of the image
            $imageUrl=$directory.$imageName; //put the image in folder or url of the image
            Image::make($myImage)->save($imageUrl);

            DB::table('clients')
                ->where('email', Session::get('clienEmail'))
                ->update(['userImage' => $imageUrl]);
            return redirect('Courier/User-Profile');
        }
        else{
            return redirect('Courier/User-Profile');
        }

    }
}
