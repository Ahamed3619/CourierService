<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\clientOrder;
use App\ordersPrice;
use Illuminate\Support\Facades\Session;
use DB;
class OrderController extends Controller
{
    public function userOrder(Request $request){
        $usersOrder=new clientOrder();
        if(Session::get('clienEmail'))
        {
            $usersOrder->senderName = $request->senderName;
            $usersOrder->senderPhone = $request->senderPhone;
            $usersOrder->senderEmail = Session::get('clienEmail');
            $usersOrder->senderAddress = $request->senderAddress;
            $usersOrder->senderDivision = $request->senderDivision;
            $usersOrder->senderCity = $request->senderCity;
            $usersOrder->receiverName = $request->receiverName;
            $usersOrder->receiverPhone = $request->receiverPhone;
            $usersOrder->receiverAddress = $request->receiverAddress;
            $usersOrder->receiverDivision = $request->receiverDivision;
            $usersOrder->receiverCity = $request->receiverCity;
            $usersOrder->productName = $request->productName;
            $usersOrder->orderQuantity = $request->orderQuantity;
            $usersOrder->orderCompany = $request->orderCompany;
            $usersOrder->conditionAgree = $request->conditionAgree;
            $usersOrder->save();
            Session::put('orderId',$usersOrder->id);
            Session::put('orderQuantity',$usersOrder->orderQuantity);
            return redirect('User/Order-Price/Page');
        }
        else{
            return redirect::back()->with('message','* Please Sign-In First *');
        }
    }

    public function userPricePage(){
        return view('front-end.orderPrice.priceCalculation');
    }

    public function orderPrice(Request $request){
        $myOrderPrice=new ordersPrice();
        if(($request->productWeight<=3)&&($request->productHeight<=5)&&($request->productWidth<=5)){
            $deliveryCharge= 50;
            $courierCharge=100;
            $totalPrice=$deliveryCharge+($courierCharge*Session::get('orderQuantity'));

            $myOrderPrice->orderId= Session::get('orderId');
            $myOrderPrice->productWeight= $request->productWeight;
            $myOrderPrice->productHeight= $request->productHeight;
            $myOrderPrice->productWidth	= $request->productWidth;
            $myOrderPrice->TotalPrice	= $totalPrice;
            $myOrderPrice->payMethod	= $request->payMethod;
            $myOrderPrice->save();

            return redirect('User/Order/Congratulation')->with(['orderPrice'=>$totalPrice]);
        }
        else if(($request->productWeight<=7)&&($request->productHeight<=10)&&($request->productWidth<=10)){
            $deliveryCharge= 80;
            $courierCharge=150;
            $totalPrice=$deliveryCharge+($courierCharge*Session::get('orderQuantity'));

            $myOrderPrice->orderId= Session::get('orderId');
            $myOrderPrice->productWeight= $request->productWeight;
            $myOrderPrice->productHeight= $request->productHeight;
            $myOrderPrice->productWidth	= $request->productWidth;
            $myOrderPrice->TotalPrice	= $totalPrice;
            $myOrderPrice->payMethod	= $request->payMethod;
            $myOrderPrice->save();

            return redirect('User/Order/Congratulation')->with(['orderPrice'=>$totalPrice]);
        }
        else if(($request->productWeight<=12)&&($request->productHeight<=15)&&($request->productWidth<=15)){
            $deliveryCharge= 100;
            $courierCharge=200;
            $totalPrice=$deliveryCharge+($courierCharge*Session::get('orderQuantity'));
            $myOrderPrice->orderId= Session::get('orderId');
            $myOrderPrice->productWeight= $request->productWeight;
            $myOrderPrice->productHeight= $request->productHeight;
            $myOrderPrice->productWidth	= $request->productWidth;
            $myOrderPrice->TotalPrice	= $totalPrice;
            $myOrderPrice->payMethod	= $request->payMethod;
            $myOrderPrice->save();
            return redirect('User/Order/Congratulation')->with(['orderPrice'=>$totalPrice]);
        }
        else{
            return redirect('User/Order-Price/Page')->with('error',"Sorry! We Can't Take The Order.Weight,Height or Width is Bigger ");
        }

    }
//    protected function savingOrderPrice($request){
//        $myOrderPrice=new ordersPrice();
//        $myOrderPrice->orderId= Session::get('orderId');
//        $myOrderPrice->productWeight= $request->productWeight;
//        $myOrderPrice->productHeight= $request->productHeight;
//        $myOrderPrice->productWidth	= $request->productWidth;
//        $myOrderPrice->payMethod	= $request->payMethod;
//    }
    public function orderCongratulation(){
        return view('front-end.orderPrice.orderSubmitted');

    }
    public function orderTrack(Request $request){
        $orderStatus= DB::table('client_orders')
            ->where(['id'=>$request->orderId])
            ->first();
        $ShipmentStatus= DB::table('orders_prices')
            ->where(['orderId'=>$request->orderId])
            ->first();
        if ($orderStatus){
            if ($ShipmentStatus) {
                $myorderStatus = "Your Order Status is: " . $orderStatus->orderStatus;
                $myShipmentStatus = "And Your Shipment is " . $ShipmentStatus->ShipmentStatus;

                return redirect('/')->with(['myorderStatus' => $myorderStatus, 'myShipmentStatus' => $myShipmentStatus]);
            }
        }
        else {

            return redirect('/')->with('message', "Sorry We couldn't Find Your Id");

        }
    }
}
