<?php

namespace App\Http\Controllers;
use App\Company;
use Image;
use Illuminate\Http\Request;

class CompaniesController extends Controller
{
    public function index(){
        return view('admin.home.addCompany');
    }

    public function saveCompany(Request $request){
        $myCompany=new Company();

        $this->validate($request,[
            'company_name'=>'required',
            'description'=>'required',
            'company_image'=>'required'
        ]);

        //intervention.io image upload package

        $companyImage=$request->file('company_image'); //for image upload we need use file('input field name')
        $imageName=$companyImage->getClientOriginalName(); //name of the image (control+space) for the function
        $directory='companyImages/'; //directory or path create of the image
        $imageUrl=$directory.$imageName; //put the image in folder or url of the image
        Image::make($companyImage)->save($imageUrl);

        $myCompany->company_name=$request->company_name;
        $myCompany->description=$request->description;
        $myCompany->company_image= $imageUrl;
        $myCompany->publication_status=$request->publication_status;
        $myCompany->save();
        return redirect('Add-Courier')->with('message','Successfully Saved Company');
    }

    public function manageCompany(){
        $allCompanies=Company::all();
        return view('admin.home.viewCompanies',['allCompanies'=> $allCompanies]);
    }
    public function unpublishedCompany($id){
        $company=Company::find($id);
        $company->publication_status=0;
        $company->save();
        return redirect('Courier/Manage-Courier')->with('message','Successfully Unpublished');
    }
    public function publishedCompany($id){
        $company=Company::find($id);
        $company->publication_status=1;
        $company->save();
        return redirect('Courier/Manage-Courier')->with('message','Successfully Published');
    }
    public function editCompany($id){
        $company=Company::find($id);
        return view('admin.home.editCompany',['company'=>$company]);
    }
    public function deleteCompany($id){
        $company=Company::find($id);
        $company->delete();
        return redirect('Courier/Manage-Courier')->with('message','Successfully Deleted');
    }
    public function updateCompany(Request $request){
        $myCompany=Company::find($request->id);

        $companyImage=$request->file('company_image'); //for image upload we need use file('input field name')
        if ($companyImage){
            unlink($myCompany->company_image);
            $imageName=$companyImage->getClientOriginalName(); //name of the image (control+space) for the function
            $directory='companyImages/'; //directory or path create of the image
            $imageUrl=$directory.$imageName; //put the image in folder or url of the image
            Image::make($companyImage)->save($imageUrl);

            $myCompany->company_name=$request->company_name;
            $myCompany->description=$request->description;
            $myCompany->company_image= $imageUrl;
            $myCompany->publication_status=$request->publication_status;
            $myCompany->save();
            return redirect('Courier/Manage-Courier')->with('message','Successfully Updated');
        }
        else{

            $myCompany->company_name=$request->company_name;
            $myCompany->description=$request->description;
            $myCompany->publication_status=$request->publication_status;
            $myCompany->save();
            return redirect('Courier/Manage-Courier')->with('message','Successfully Updated');

        }
    }
}
