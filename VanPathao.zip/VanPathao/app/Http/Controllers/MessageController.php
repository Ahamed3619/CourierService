<?php

namespace App\Http\Controllers;

use App\ClientMessage;
use Illuminate\Http\Request;
use Redirect;

class MessageController extends Controller
{
    public function clientMessage(Request $request){
        $userMessage=new ClientMessage();
        $userMessage->contactName=$request->contactName;
        $userMessage->contactEmail=$request->contactEmail;
        $userMessage->contactPhone=$request->contactPhone;
        $userMessage->comment=$request->comment;
        $userMessage->save();
        return redirect::back()->with('message','Message Successfully Send');
    }
    public function viewMessage(){
        $allMessage=ClientMessage::all();
        return view('admin.home.messageView',['allMessage'=>$allMessage]);
    }
    public function deleteMessage($id){
        $deleteMessage=ClientMessage::find($id);
        $deleteMessage->delete();
        return redirect::back()->with('message','Message Successfully Deleted');
    }
}
