<?php

namespace App\Http\Controllers;
use App\Company;

use Illuminate\Http\Request;

class VanPathaoController extends Controller
{
    public function index(){
        $myCompany=Company::where('publication_status',1)
            ->orderBy('id', 'asc')
            ->get();
        return view('front-end.home.index',[ 'myCompany'=> $myCompany]);
    }

    public function companies(){
//        $myCompany=Company::where('publication_status',1)
//            ->orderBy('id', 'asc')
//            ->get();
        return view('front-end.companies.companies');
    }

    public function order(){
        return view('front-end.order.order');
    }

    public function about(){
        return view('front-end.about.about');
    }

    public function price(){
        return view('front-end.price.price');
    }

    public function contact(){
        return view('front-end.contact.contact');
    }

    public function search(){
        return view('front-end.courierSearch.search');
    }
}
