<?php

namespace App\Http\Controllers;

use App\ClientOrder;
use App\ordersPrice;
use Illuminate\Http\Request;
use DB;
use PDF;

class AdminOrderController extends Controller
{
    public function newOrder(){
        $allOrder=ClientOrder::all()->sortByDesc('id');
        return view('admin.home.allOrder',['allOrder'=>$allOrder]);
    }
    public function OrderConfirm($id){
        $confirmOrder=ClientOrder::find($id);
        $confirmOrder->orderStatus='Confirmed';
        $confirmOrder->save();
        return redirect()->route('newOrder');
    }
    public function OrderPending($id){
        $pendingOrder=ClientOrder::find($id);
        $pendingOrder->orderStatus='Pending';
        $pendingOrder->save();
        return redirect()->route('newOrder');
    }
    public function OrderEdit($id){
        return view('admin.home.editShipment',['orderId'=>$id]);

    }
    public function ShipmentStatus(Request $request){

        $this->validate($request,[
            'orderId'=>'required',
            'ShipmentStatus'=>'required'

        ]);

        $ShipmentStatus= DB::table('orders_prices')
            ->where(['orderId'=>$request->orderId])
            ->first();


        if($ShipmentStatus){
            DB::table('orders_prices')->update(['ShipmentStatus' => $request->ShipmentStatus]);
            return redirect('Courier/New-Order')->with('message','Shipment Status Changed');
        }
        else{
            return redirect('Courier/New-Order')->with('message','Id Not Found');
        }


    }
    public function OrderDelete($id){
        $deleteOrder=ClientOrder::find($id);
        $deleteOrder->delete();
        return redirect()->route('newOrder')->with('message','Successfully Deleted Order');
    }
    public function ViewOrder($id){
        $clientOrder=ClientOrder::find($id);
        $orderPrice= DB::table('orders_prices')
            ->where(['orderId'=>$id])
            ->first();

        return view('admin.home.orderDetails',['clientOrder'=>$clientOrder,'orderPrice'=>$orderPrice]);
    }

    public function ViewOrderInvoice($id){
        $clientOrder=ClientOrder::find($id);
        $orderPrice= DB::table('orders_prices')
            ->where(['orderId'=>$id])
            ->first();

        return view('admin.home.orderInvoice',['clientOrder'=>$clientOrder,'orderPrice'=>$orderPrice]);
    }
    public function DownloadOrder($id){
        $clientOrder=ClientOrder::find($id);
        $orderPrice= DB::table('orders_prices')
            ->where(['orderId'=>$id])
            ->first();
        $pdf = PDF::loadView('admin.home.downloadInvoice',['clientOrder'=>$clientOrder,'orderPrice'=>$orderPrice]);


        return $pdf->stream('invoice.pdf');
        //return $pdf->download('invoice.pdf');
    }
}
