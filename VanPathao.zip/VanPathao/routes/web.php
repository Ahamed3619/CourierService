<?php

Route::get('/',[

    'uses'=>'VanPathaoController@index',
    'as'=>'/'

]);

Route::get('companies',[
        'uses'=>'VanPathaoController@companies',
        'as'=>'companies'
]);

Route::get('order',[
    'uses'=>'VanPathaoController@order',
    'as'=>'order'
]);

Route::get('about',[
    'uses'=>'VanPathaoController@about',
    'as'=>'about'
]);

Route::get('price',[
    'uses'=>'VanPathaoController@price',
    'as'=>'price'
]);

Route::get('contact',[
    'uses'=>'VanPathaoController@contact',
    'as'=>'contact'
]);
Route::get('search-Map',[
    'uses'=>'VanPathaoController@search',
    'as'=>'search'
]);
Route::get('Courier/Add-Courier',[
    'uses'=>'CompaniesController@index',
    'as'=>'addCompany'
]);
Route::post('Courier/Save-Courier',[
    'uses'=>'CompaniesController@saveCompany',
    'as'=>'new-courier'
]);
Route::get('Courier/Manage-Courier',[
    'uses'=>'CompaniesController@manageCompany',
    'as'=>'manageCompany'
]);
Route::get('Courier/Unpublished-Courier/{id}',[
    'uses'=>'CompaniesController@unpublishedCompany',
    'as'=>'company_unpublished'
]);
Route::get('Courier/Published-Courier/{id}',[
    'uses'=>'CompaniesController@publishedCompany',
    'as'=>'company_published'
]);
Route::get('Courier/Edit-Courier/{id}',[
    'uses'=>'CompaniesController@editCompany',
    'as'=>'edit_company'
]);
Route::get('Courier/Delete-Courier/{id}',[
    'uses'=>'CompaniesController@deleteCompany',
    'as'=>'delete_company'
]);
Route::post('Courier/Update-Courier',[
    'uses'=>'CompaniesController@updateCompany',
    'as'=>'update-courier'
]);
Route::post('Courier/Loggedin',[
    'uses'=>'ClientController@clientLogin',
    'as'=>'clientLogin'
]);
Route::post('Courier/User-Loggedin',[
    'uses'=>'ClientController@clientSignup',
    'as'=>'client-signup'
]);
Route::get('Courier/User-Profile',[
    'uses'=>'ClientController@userProfile',
    'as'=>'userProfile'
]);

Route::post('Courier/User-Logout',[
    'uses'=>'ClientController@clientLogout',
    'as'=>'clientLogout'
]);
Route::get('Courier/User-Settings',[
    'uses'=>'ClientController@changePassword',
    'as'=>'changePassword'
]);
Route::get('Courier/Edit-Profile',[
    'uses'=>'ClientController@editProfile',
    'as'=>'editProfile',
    'middleware'=>'UserCheck'
]);
Route::post('Courier/Update-Profile',[
    'uses'=>'ClientController@clientUpdate',
    'as'=>'clientUpdate'
]);
Route::post('Courier/Change-Password',[
    'uses'=>'ClientController@passwordUpdate',
    'as'=>'passwordUpdate'
]);
Route::post('User/Image',   [
    'uses'=>'ClientController@userImage',
    'as'=>'userImage'
]);
Route::post('User/Order',   [
    'uses'=>'OrderController@userOrder',
    'as'=>'userOrder'
]);
Route::get('User/Order-Price/Page', 'OrderController@userPricePage')->middleware('UserCheck');

Route::post('User/Order-Price',   [
    'uses'=>'OrderController@orderPrice',
    'as'=>'orderPrice'

]);
Route::get('User/Order/Congratulation', 'OrderController@orderCongratulation')->middleware('UserCheck');

Route::post('User/Order-Tracking',[
    'uses'=>'OrderController@orderTrack',
    'as'=>'orderTrack'
]);
Route::get('Courier/New-Order',[
    'uses'=>'AdminOrderController@newOrder',
    'as'=>'newOrder'
]);
Route::get('Order/Confirm/{id}',[
    'uses'=>'AdminOrderController@OrderConfirm',
    'as'=>'order_confirm'
]);
Route::get('Order/Pending/{id}',[
    'uses'=>'AdminOrderController@OrderPending',
    'as'=>'order_pending'
]);
Route::get('Order/Edit-Shipment/{id}',[
    'uses'=>'AdminOrderController@OrderEdit',
    'as'=>'edit_order'
]);
Route::get('Order/Delete/{id}',[
    'uses'=>'AdminOrderController@OrderDelete',
    'as'=>'delete_order'
]);
Route::get('Order/View/{id}',[
    'uses'=>'AdminOrderController@ViewOrder',
    'as'=>'view_order'
]);
Route::get('Order/Download-Invoice/{id}',[
    'uses'=>'AdminOrderController@DownloadOrder',
    'as'=>'download_order'
]);
Route::get('Order/Invoice/{id}',[
    'uses'=>'AdminOrderController@ViewOrderInvoice',
    'as'=>'view_order_invoice'
]);
Route::post('Order/Shipment',[
    'uses'=>'AdminOrderController@ShipmentStatus',
    'as'=>'shipment-status'
]);
Route::post('Client/Message',[
    'uses'=>'MessageController@clientMessage',
    'as'=>'clientMessage'
]);
Route::get('View/Message',[
    'uses'=>'MessageController@viewMessage',
    'as'=>'view-message'
]);
Route::get('Delete/Message/{id}',[
    'uses'=>'MessageController@deleteMessage',
    'as'=>'delete_message'
]);
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
