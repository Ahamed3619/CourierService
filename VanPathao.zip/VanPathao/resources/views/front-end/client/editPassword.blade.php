@extends('front-end.client.profileContent')

@section('content')
    <ul class="nav nav-tabs" id="myTab">
        <li class="active"><a href="#inbox" data-toggle="tab"><i class="fa fa-edit"></i> Edit</a></li>
    </ul>

    <div class="tab-content" >
        <div class="tab-pane active" id="inbox" style="border-radius:0;">
            <a style="text-decoration: none">
                <div class="btn-toolbar well well-lg" role="toolbar"  style="margin:0px; border-radius:0;font-size: 18px;">
                    <div class="logo">
                        <img src="{{asset('/')}}/front-end/img/icons.png" height="100" width="100" class="img img-responsive img-circle center-block"/>
                    </div><!-- /.logo -->
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    {{Form::open(['route'=>'passwordUpdate', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])}}
                    <div class="controls">
                        Password
                        <input type="password" name="password" placeholder="Password" class="form-control" />
                        <span class="text-danger">{{$errors->has('password') ? $errors->first('password') : ''}}</span>
                        <br>
                        Confirm-Password
                        <input type="password" id="password-confirm"  placeholder="Retype-Password" class="form-control" name="password_confirmation"/>
                        <span class="text-danger">{{$errors->has('password') ? $errors->first('password') : ''}}</span>
                        <br>
                        <button type="submit" name="btn" class="btn btn-primary btn-block btn-custom">Change Password</button>
                    </div><!-- /.controls -->
                    {{Form::close()}}

                </div>
            </a>
        </div>
    </div>
@endsection