@extends('front-end.client.profileContent')

@section('content')
    <ul class="nav nav-tabs" id="myTab">
        <li class="active"><a href="#inbox" data-toggle="tab"><i class="fa fa-file-text-o"></i> Details</a></li>
        <li><a href="#sent" data-toggle="tab"><i class="fa fa-shopping-cart"></i> My Order</a></li>
    </ul>

    <div class="tab-content" >
        <div class="tab-pane well well-lg active" id="inbox" style="border-radius:0;">
            <a>
                <div class="btn-toolbar " role="toolbar"  style="margin:0px; background-color: white; border-radius:0;font-size: 18px;">
                    <br/><br/>
                    <div class="btn-group col-md-3">Name </div>
                    <div class="btn-group col-md-8">{{$checklogin->name}}  </div>
                    <br/><br/>
                    <div class="btn-group col-md-3">Email </div>
                    <div class="btn-group col-md-8">{{$checklogin->email}} </div>
                    <br/><br/>
                    <div class="btn-group col-md-3">Phone </div>
                    @if($checklogin->phone)
                        <div class="btn-group col-md-8">{{$checklogin->phone}}</div>
                    @else
                        <div class="btn-group col-md-8"><span style="color: red">* Add Phone </span>  </div>
                    @endif
                    <br/><br/>
                    <div class="btn-group col-md-3">Address </div>
                    @if($checklogin->address)
                        <div class="btn-group col-md-8">{{$checklogin->address}}</div>
                    @else
                        <div class="btn-group col-md-8"><span style="color: red">* Add Place</span>  </div>
                    @endif

                    {{--<div class="pull-right" > <button class="btn btn-primary btn-xs" data-toggle="modal" data-target=".bs-example-modal-lg"><i class="glyphicon glyphicon-edit"> Edit</i></button></div>--}}
                    <br/><br/><br/><br/>
                </div>
            </a>

            <br>
            <a href="{{route('editProfile')}}"><button class="btn btn-primary btn-xs"><i class="glyphicon glyphicon-edit"></i> Edit Your Information </button></a>
        </div>


        <div class="tab-pane" id="sent" style="border-radius:0;font-size: 18px;">
            <a  style=" text-decoration: none;">
                <div class="btn-toolbar well well-lg" role="toolbar"  style="margin:0px;border-radius:0;">
                    <table class="table" style="background-color: #ffffff;">
                        @php($i=0)
                        @foreach($myOrder as $allOrder)
                        <tbody >
                            <tr>
                                <td >Serial.</td>
                                <td scope="row">{{++$i}}</td>
                            </tr>
                            <tr>
                                <td >OrderID</td>
                                <td>{{$allOrder->id}}</td>
                            </tr>
                            <tr>
                                <td scope="col">Product</td>
                                <td>{{$allOrder->productName}}</td>
                            </tr>
                            <tr>
                                <td scope="col">Quantity</td>
                                <td>{{$allOrder->orderQuantity}}</td>
                            </tr>
                            <tr>
                                <td scope="col">Receiver</td>
                                <td>{{$allOrder->receiverName}}</td>
                            </tr>
                            <tr>
                                <td scope="col">Date</td>
                                <td>{{ $allOrder->created_at->format('d M Y') }}</td>
                            </tr>
                        <tbody>
                            <br><br>
                        @endforeach
                        {{$myOrder->links()}}
                    </table>
                </div>
            </a>
        </div>
    </div>
@endsection