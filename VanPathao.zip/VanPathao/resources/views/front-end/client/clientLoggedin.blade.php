@extends('front-end.master')

@section('signinSignup')

    @include('front-end.includes.loginChecker')

@endsection

@section('menu')
    @include('front-end.includes.homeMenu')
@endsection

@section('title')
    {{ $checklogin->name}}
@endsection

@section('body')

    @include('front-end.includes.homeBody')

@endsection