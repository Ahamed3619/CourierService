@extends('front-end.master')
@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('title')
    Profile
@endsection

@section('body')

    <div id="user-background">
        <div class="container">
            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked well">
                    <li><a href="{{route('/')}}"><i class="fa fa-home"></i> Home</a></li>
                    <li class="{{ request()->is('Courier/User-Profile') ? 'active' : '' }}"><a href="{{route('userProfile')}}"><i class="fa fa-user"></i> Profile</a></li>
                    <li class="{{ request()->is('Courier/User-Settings') ? 'active' : '' }}"><a href="{{route('changePassword')}}"><i class="fa fa-key"></i> Change Password</a></li>
                    <li class="{{ request()->is('Courier/Edit-Profile') ? 'active' : '' }}"><a href="{{route('editProfile')}}"><i class="glyphicon glyphicon-edit"></i> Edit Profile</a></li>
                    <li><a href="{{ route('clientLogout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">

                            <i class="fa fa-sign-out fa-fw"></i> Logout

                        </a>
                        <form id="logout-form" action="{{ route('clientLogout') }}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </li>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="panel">
                    <div class="name"><small>{{$checklogin->name}} Profile</small></div>

                    @if($checklogin->userImage)
                        <img class="pic img-circle" src="{{asset($checklogin->userImage)}}" alt="..." style="height: 150px;width: 150px">
                    @else
                    <img class="pic img-circle" src="http://placehold.it/150x150" alt="...">
                    @endif
                    <a href="#"  style="text-decoration: none;">
                        {{Form::open(['route'=>'userImage', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data','accept'=>'image/*'])}}


                        <label for="inputfile" class="btn btn-xs btn-primary" style=" margin:10px 0px 0px 38px; ">
                            <span class="glyphicon glyphicon-picture" aria-hidden="true"></span>
                            Image
                            <input type="file" name='inputfile' id='inputfile' style="display:none">
                        </label>
                        <button type="submit" class="btn btn-xs btn-danger"  style=" margin-top:10px; ">Upload</button>
                        {{Form::close()}}
                    </a>

                </div>

                <br><br><br>
                @yield('content')


            </div>
        </div>


    </div>
@endsection