@extends('front-end.client.profileContent')

@section('content')
    <ul class="nav nav-tabs" id="myTab">
        <li class="active"><a href="#inbox" data-toggle="tab"><i class="fa fa-edit"></i> Edit</a></li>
    </ul>

    <div class="tab-content" >
        <div class="tab-pane active" id="inbox" style="border-radius:0;">
            <a style="text-decoration: none">
                <div class="btn-toolbar well well-lg" role="toolbar"  style="margin:0px; border-radius:0;font-size: 18px;">
                        <div class="logo">
                            <img src="{{asset('/')}}/front-end/img/icons.png" height="100" width="100" class="img img-responsive img-circle center-block"/>
                        </div><!-- /.logo -->
                        {{Form::open(['route'=>'clientUpdate', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])}}
                        <div class="controls">
                            Name
                            <input  name="name" placeholder="Your-Name" class="form-control" value="{{$checklogin->name}}" />
                            <span class="text-danger">{{$errors->has('name') ? $errors->first('name') : ''}}</span>
                            <br>
                            Email
                            <input name="email" placeholder="Email" class="form-control" value="{{$checklogin->email}}"/>
                            <span class="text-danger">{{$errors->has('email') ? $errors->first('email') : ''}}</span>
                            <br>
                            Phone
                            <input  name="phone" placeholder="Phone" class="form-control" value="{{$checklogin->phone}}"/>
                            <span class="text-danger">{{$errors->has('phone') ? $errors->first('phone') : ''}}</span>
                            <br>
                            Address
                            <textarea name="address" style="width: 100%;color: #555555;font-size: 15px"> {{$checklogin->address}} </textarea>
                            <span class="text-danger">{{$errors->has('address') ? $errors->first('address') : ''}}</span>
                            <br><br>
                            <button type="submit" name="btn" class="btn btn-primary btn-block btn-custom">Update Info</button>

                        </div><!-- /.controls -->
                        {{Form::close()}}

                </div>
            </a>
        </div>
    </div>
@endsection