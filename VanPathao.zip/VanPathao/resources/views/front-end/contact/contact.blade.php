@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')
    @include('front-end.includes.contactMenu')
@endsection

@section('title')
    CONTACT US
@endsection

@section('body')

    @include('front-end.includes.contactContent')
    <!--Google Map-->

    <div id="map" style="width:100%;height:500px;"></div>

    <!--Google Map End-->
@endsection