@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')
    <!-- Menu Bar Start -->

    <div class="" style="background-color: black"><!-- background-side start  -->
        <nav class="second-navbar"><!-- second-navbar start  -->
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand page-scroll" id="title" href="{{route('/')}}"><i class="fa fa-truck" aria-hidden="true"></i>Courier BD</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="hidden">
                            <a href="#page-top"></a>
                        </li>
                        <li>
                            <a class="{{ request()->is('/') ? 'active' : '' }}" href="{{route('/')}}">Home</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('companies') ? 'active' : '' }}" href="{{route('companies')}}">Companies</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('order') ? 'active' : '' }}" href="{{route('order')}}">Order</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('about') ? 'active' : '' }}" href="{{route('about')}}">About Us</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('price') ? 'active' : '' }}" href="{{route('price')}}">Price</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('contact') ? 'active' : '' }}" href="{{route('contact')}}">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- /.container-fluid -->
        </nav><!-- second-navbar end  -->
    </div><!-- background-side end  -->

    <!-- Menu Bar end -->
@endsection

@section('title')

    Price Calculate
@endsection

@section('body')
    <!-- price Calculation  Start -->
    <div class="order">
        <div class="container">
            <br><br><br><br>
            <h2 class="order-title"><hr><br> Calculate Your <strong>Price</strong>  </h2><br>
            <hr><br><br>
            <div  class="col-lg-6 col-md-6 col-sm-12">
                <img src="{{asset('/')}}/front-end/img/man.png">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12" id="order-box">
                <h1 class="text-center text-danger" style="font-size: 20px;">{{Session::get('error')}}</h1>
                <h3>Price Includes Our Home Delivery Charges. Please Give Valid Information to proceed The Order.</h3>
                <!--Form Start-->
                {{Form::open(['route'=>'orderPrice','method'=>'POST','class'=>'form-section','enctype'=>'multipart/form-data'])}}



                <span style="font-size:17px;font-weight:bold;">Weight<span style="color:red;font-size:20px"> *</span></span>
                <input type="text" required pattern="^\d{0,8}(\.\d{1,4})?$" name="productWeight" placeholder="Weight in K.G"  title="Weight in KG"/>

                <span style="font-size:17px;font-weight:bold;">Height<span style="color:red;font-size:20px"> *</span></span>
                <input type="text" required pattern="^\d{0,8}(\.\d{1,4})?$" name="productHeight" placeholder="Height in C.M"  title="Height in C.M"/>

                <span style="font-size:17px;font-weight:bold;">Width<span style="color:red;font-size:20px"> *</span></span>
                <input type="text" required pattern="^\d{0,8}(\.\d{1,4})?$" name="productWidth" placeholder="Width in C.M"  title="Height in C.M"/>
                <span style="font-size:17px;font-weight:bold;">Payment<span style="color:red;font-size:20px"> *</span></span><br>
                <input type="radio" name="payMethod" value="In-Cash" checked required> Hand Cash

                <input type="submit" value="Submit Order">


            {{Form::close()}}

            <!--Form End-->
            </div>
        </div>
    </div>
    <!-- Order Div End -->


    <!-- price Calculation End -->

@endsection