
@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')


    <!-- Menu Bar Start -->

    <div class="" style="background-color: black"><!-- background-side start  -->
        <nav class="second-navbar"><!-- second-navbar start  -->
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand page-scroll" id="title" href="{{route('/')}}"><i class="fa fa-truck" aria-hidden="true"></i>Courier BD</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="hidden">
                            <a href="#page-top"></a>
                        </li>
                        <li>
                            <a class="{{ request()->is('/') ? 'active' : '' }}" href="{{route('/')}}">Home</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('companies') ? 'active' : '' }}" href="{{route('companies')}}">Companies</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('order') ? 'active' : '' }}" href="{{route('order')}}">Order</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('about') ? 'active' : '' }}" href="{{route('about')}}">About Us</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('price') ? 'active' : '' }}" href="{{route('price')}}">Price</a>
                        </li>
                        <li>
                            <a class="{{ request()->is('contact') ? 'active' : '' }}" href="{{route('contact')}}">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- /.container-fluid -->
        </nav><!-- second-navbar end  -->
    </div><!-- background-side end  -->

    <!-- Menu Bar end -->

@endsection
@section('title')

    Order Submitted
@endsection

@section('body')
    <!-- price Calculation  Start -->
    <div class="order">
        <div class="container">
            <div class="col-lg-12 col-md-12 col-sm-12" style="padding:200px 0px 200px 0px;">
                <h1 class="text-center text-success"> Congratulation!! {{$checklogin->name}}</h1>
                <p class="text-center text-success" style="font-size: 25px;">Order Submitted. Your Order Id : {{Session::get('orderId')}}. Total Price: {{Session::get('orderPrice')}} TK.<br> Product Quantity: {{Session::get('orderQuantity')}} We will Contact You Soon. Check Your Email & Phone. </p>
            </div>
        </div>
    </div>
    <!-- Order Div End -->


    <!-- price Calculation End -->

@endsection