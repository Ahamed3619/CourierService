@extends('front-end.master')

@section('signinSignup')

    @include('front-end.includes.loginChecker')

@endsection


@section('menu')
    @include('front-end.includes.companiesMenu')
@endsection


@section('title')

    ASSOCIATED COMPANIES
@endsection

@section('body')

    <!-- All Courier Companies Start -->

    <div class="courier-companies">
        <div class="container">
            <h2 class="Companies-title"><hr><br> <strong>Associated</strong> Companies </h2><br>
            <hr><br><br>
            @foreach($myCompany as $companies)
                <div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="thumbnail">
                        <a class="first-item" href="{{route('search')}}">
                            <img src="{{$companies->company_image}}"alt="Companies">
                            <div class="portfolio-box-caption">
                                <div class="portfolio-box-caption-content ">
                                    <div class="first-content">
                                        Find Branches
                                    </div>
                                </div>
                            </div>
                        </a>
                        <div class="caption">
                            <a href="{{route('search')}}" class="company-name"><h4><strong>{{$companies->company_name}}</strong></h4></a>
                            <p>{!!$companies->description  !!}</p>

                            <p class="pull-right text-danger">7 Reviews</p>
                            <p class="text-success">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half"></i>
                            </p>
                        </div>
                    </div>
                </div>
            @endforeach


        </div>
    </div>

    <!-- All Courier Companies End -->

@endsection