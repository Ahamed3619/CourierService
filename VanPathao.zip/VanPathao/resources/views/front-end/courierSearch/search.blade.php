@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')
    @include('front-end.includes.searchMenu')
@endsection

@section('title')
    MAP-SEARCH
@endsection

@section('body')

    <input id="pac-input" class="controls" type="text" placeholder="Find Courier">
    <div id="map" style="width:100%;height:600px;"></div>

@endsection