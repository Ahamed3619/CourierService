@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')
    @include('front-end.includes.priceMenu')
@endsection


@section('title')
    PLAN & PRICING
@endsection

@section('body')
    <!-- price div start -->

    <div class="price">
        <div class="container">
            <h2 class="price-title"><hr><br> Pricing <strong>&</strong> Plan </h2><br>
            <hr><br><br>
            <div class="col-lg-4 col-sm-12 col-md-4">
                <div class="thumbnail" id="hover-border">
                    <h1 class="item-one">
                        250 TK .
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content ">
                                <div class="content-one">
                                    <p>ENTIRE DHAKA CITY<p>
                                </div>
                            </div>
                        </div>
                    </h1>
                    <div class="caption">
                        <h3><strong>Dhaka</strong> to <strong>Dhaka</strong> </h3>
                        <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                        <h5>Duration: <span style="color:gray"> 2 Days</span></h5>
                        <h5>Support: <span style="color:gray"> Yes</span></h5>
                        <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-12 col-md-4">
                <div class="thumbnail" id="thumb-border">
                    <h1 class="item-one">
                        350 TK .
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content ">
                                <div class="content-one">
                                    <p>OUTSIDE OF DHAKA<p>
                                </div>
                            </div>
                        </div>
                    </h1>
                    <div class="caption">
                        <h3><strong>Dhaka</strong> to <strong>Other's</strong> </h3>
                        <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                        <h5>Duration: <span style="color:gray"> 4 Days</span></h5>
                        <h5>Support: <span style="color:gray"> Yes</span></h5>
                        <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                    </div>
                </div>
            </div>


            <div class="col-lg-4 col-sm-12 col-md-4">
                <div class="thumbnail" id="hover-border">
                    <h1 class="item-one">
                        450 TK .
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content ">
                                <div class="content-one">
                                    <p>OUTSIDE OF BANGLADESH<p>
                                </div>
                            </div>
                        </div>
                    </h1>
                    <div class="caption">
                        <h3><strong>Dhaka</strong> to <strong>Worldwide</strong> </h3>
                        <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                        <h5>Duration: <span style="color:gray"> 7 Days</span></h5>
                        <h5>Support: <span style="color:gray"> Yes</span></h5>
                        <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                    </div>
                </div>
            </div>


        </div>
    </div><!--Price div End-->
@endsection