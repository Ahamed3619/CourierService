<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>@yield('title')</title>

    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="icon" href="{{asset('/')}}/front-end/img/favicon.ico" type="image/x-icon">

    <!-- Bootstrap -->
    <link href="{{asset('/')}}front-end/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('/')}}front-end/css/bootstrap-theme.css" rel="stylesheet">
    <link href="{{asset('/')}}front-end/css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('/')}}front-end/css/jquery-ui.min.css" media="all" />
    <link rel="stylesheet" type="text/css" href="{{asset('/')}}front-end/css/uikit.min.css" media="all" />

    <!-- Bootstrap validator css-->
    <link rel="stylesheet" type="text/css" href="{{asset('/')}}front-end/css/bootstrapValidator.min.css" media="all" />

    <!-- Bootstrap validator js-->
    <script type="text/javascript" src="{{asset('/')}}front-end/js/bootstrapValidator.min.js"></script>

    <!-- fontawesome stylesheet -->
    <link rel="stylesheet" href="{{asset('/')}}front-end/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{asset('/')}}front-end/css/font-awesome.css">


    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Pacifico" />
    <link href='https://fonts.googleapis.com/css?family=Courgette' rel='stylesheet'>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="wrapper"><!-- Wrapper start -->


    <!-- top header start -->
    <header class="top-header">
        <div class="left-header">

            <ul class="list-inline">
                <li id="bord">
                    <a href="#" class="phone">
                        <i class="fa fa-phone pr-5 pl-10">  </i> +55 4377-634-7071
                    </a>
                </li>
                <li id="borde">
                    <a href="#" class="mail">
                        <i class="fa fa-envelope-o pr-5 pl-10">  </i>  service@courierbd.com
                    </a>
                </li>
            </ul>

        </div>
        @yield('signinSignup')

    </header><!-- top header end -->

    <!-- Menu Bar Start -->
    @yield('menu')



    <!-- Menu Bar end -->

    @yield('body')



    <!-- social-media div start -->

    <div class="social-media">
        <div class="container">

            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="company-address">
                    <a href="{{route('/')}}" class="courier-logo">
                        <i class="fa fa-truck" aria-hidden="true"></i>
                        Courier BD
                    </a>
                    <br><br><br>
                    <!--Scroll up button-->
                    <div class='scrolltop'>
                        <div class='scroll icon'><i class="fa fa-4x fa-angle-up"></i>
                        </div>
                    </div>
                    <!--Scroll up button end-->

                    <a href="#" class="sign">
                        <i class="fa fa-map-marker"></i>
                        Dhanmondi, Sukrabad, Dhaka-1200.
                    </a>
                    <br><br>

                    <a href="tel:+55-417-634-7071" class="sign">
                        <i class="fa fa-phone pr-5 pl-10"></i> +55 4377-634-7071
                    </a>
                    <br><br>

                    <a href="mailto:sales@carhouse.com" class="sign">
                        <i class="fa fa-envelope-o pr-5 pl-10"></i> service@courierbd.com
                    </a>
                </div>
                <br><br><br>

            </div>
            <div class="col-lg-2 col-sm-6 col-md-6">
                <div class="quick-link">
                    <h3>QUICK LINKS</h3>
                    <br><br>
                    <li>
                        <a class="page-scroll"  href="{{route('companies')}}">Companies</a>
                    </li>

                    <li>
                        <a class="page-scroll"  href="{{route('about')}}">About Us</a>
                    </li>

                    <li>
                        <a class="page-scroll"  href="{{route('about')}}">Team</a>

                    </li>

                    <li>
                        <a class="page-scroll"  href="{{route('contact')}}">Contact</a>
                    </li>

                </div>
                <br><br><br>

            </div>
            <div class="col-lg-3 col-sm-6 col-md-6">
                <div class="important-link">
                    <h3>IMPORTANT LINKS</h3>
                    <br><br>
                    <li>
                        <a class="page-scroll"  href="{{route('order')}}">Order</a>
                    </li>

                    <li>
                        <a class="page-scroll"  href="{{route('price')}}">Price</a>
                    </li>

                    <li>
                        <a class="page-scroll"  href="{{route('order')}}">Payment Method</a>
                    </li>

                </div>
                <br><br><br>

            </div>

            <div class="col-lg-3 col-sm-6 col-md-6">
                <div class="social-logo">
                    <h3>CONNECT WITH US</h3>
                    <br><br><br>
                    <a href="https://www.fb.com">
                <span class="fa-stack fa-lg">
                  <i class="fa fa-circle  fa-stack-2x"></i>
                  <i class="fa fa-twitter  fa-stack-1x fa-inverse "></i>
                </span>
                    </a>


                    <a href="https://www.fb.com">
                <span class="fa-stack fa-lg">
                  <i class="fa fa-circle  fa-stack-2x"></i>
                  <i class="fa fa-facebook  fa-stack-1x fa-inverse "></i>
                </span>
                    </a>


                    <a href="https://www.fb.com">
                <span class="fa-stack fa-lg">
                  <i class="fa fa-circle  fa-stack-2x"></i>
                  <i class="fa fa-youtube  fa-stack-1x fa-inverse "></i>
                </span>
                    </a>


                    <a href="https://www.fb.com">
                <span class="fa-stack fa-lg">
                  <i class="fa fa-circle  fa-stack-2x"></i>
                  <i class="fa fa-google-plus  fa-stack-1x fa-inverse "></i>
                </span>
                    </a>



                </div>
                <br><br><br>

            </div>


        </div>
    </div><!--social-media div End-->

    <!-- Footer -->
    <div class="copyrights">
        <div class="container">

            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="copyright-text">
                    <p>©
                        <span id="copyright">
                            <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
                            </script>
                          </span>, All rights reserved.
                    </p>
                </div><!-- end copyright-text -->
            </div><!-- end widget -->

            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="design-developer">
                    <p style="text-align: right;">Design and <i class="fa fa-heart"></i> by Courier BD </p>
                </div><!-- end copyright-text -->
            </div><!-- end widget -->
        </div><!-- end container -->
    </div><!-- end copyrights -->
    <!-- Footer -->

</div> <!-- wrapper end -->



<script type="text/javascript" src="{{asset('/')}}front-end/js/myjs.js"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Bootstrap validator js-->
<script type="text/javascript" src="{{asset('/')}}front-end/js/bootstrapValidator.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="{{asset('/')}}front-end/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="{{asset('/')}}front-end/js/easing.js"></script>
<script type="text/javascript" src="{{asset('/')}}front-end/js/real.js"></script>
<script type="text/javascript" src="{{asset('/')}}front-end/js/uikit.min.js"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" ></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->


<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="{{asset('/')}}front-end/js/bootstrap.js" type="text/javascript"></script>

<script type="text/javascript">
    /*navbar fixed*/

    jQuery("document").ready(function($){

        var nav = $('.second-navbar');

        $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                nav.addClass("f-nav");
            } else {
                nav.removeClass("f-nav");
            }
        });

    });

    /*Navbar fixed end*/

    /*jquery fadein and out in about us section*/

    $(document).ready(function(){
        $(window).scroll(function(){

            if($(window).scrollTop() > 2200)
            {
                $('#about-order').fadeIn(2000).animate;


            }
            else{
                $('#about-order').fadeOut(300);
            }

        });
    });

    $(document).ready(function(){
        $(window).scroll(function(){

            if($(window).scrollTop() > 2200)
            {
                $('#about-wait').fadeIn(3000).animate;


            }
            else{
                $('#about-wait').fadeOut(300);
            }

        });
    });

    $(document).ready(function(){
        $(window).scroll(function(){

            if($(window).scrollTop() > 2200)
            {
                $('#about-delivery').fadeIn(4000).animate;


            }
            else{
                $('#about-delivery').fadeOut(500);
            }

        });
    });

    $(document).ready(function(){
        $(window).scroll(function(){

            if($(window).scrollTop() > 2200)
            {
                $('#about-worldwide').fadeIn(5000).animate;


            }
            else{
                $('#about-worldwide').fadeOut(500);
            }

        });
    });
    /*jquery fadein and out*/

    /*jquery smooth scroll up button*/

    $(window).scroll(function() {
        if ($(this).scrollTop() > 2500 ) {
            $('.scrolltop:hidden').stop(true, true).fadeIn();
        } else {
            $('.scrolltop').stop(true, true).fadeOut();
        }
    });
    $(function(){$(".scroll").click(function(){$("html,body").animate({scrollTop:$(".trust").offset().top},"50");return false})})


    /*jquery smooth scroll up button end*/


</script>
{{--<!--Google Map-->--}}
{{--<script>--}}
    {{--function initMap() {--}}
        {{--var uluru = {lat: 23.7791946, lng: 90.3612763};--}}
        {{--var map = new google.maps.Map(document.getElementById('googleMap'), {--}}
            {{--zoom: 15,--}}
            {{--center: uluru--}}
        {{--});--}}
        {{--var marker = new google.maps.Marker({--}}
            {{--position: uluru,--}}
            {{--map: map--}}
        {{--});--}}
    {{--}--}}
{{--</script>--}}

{{--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpBHXBCPjgNr31q7dVBRLOhPsy2jKLAjE&callback=initMap">--}}

{{--</script>--}}
{{--<!--//Google Map-->--}}

<script>

    function initAutocomplete() {


        var map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 23.7791946, lng: 90.3612763},
            zoom: 15,
            mapTypeId: 'roadmap'
        });

        // Create the search box and link it to the UI element.
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function() {
            searchBox.setBounds(map.getBounds());
        });

        var markers = [];
        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function() {
            var places = searchBox.getPlaces();

            if (places.length == 0) {
                return;
            }

            // Clear out the old markers.
            markers.forEach(function(marker) {
                marker.setMap(null);
            });
            markers = [];

            // For each place, get the icon, name and location.
            var bounds = new google.maps.LatLngBounds();
            places.forEach(function(place) {
                if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                }
                var icon = {
                    url: place.icon,
                    size: new google.maps.Size(71, 71),
                    origin: new google.maps.Point(0, 0),
                    anchor: new google.maps.Point(17, 34),
                    scaledSize: new google.maps.Size(25, 25)
                };

                // Create a marker for each place.
                markers.push(new google.maps.Marker({
                    map: map,
                    icon: icon,
                    title: place.name,
                    position: place.geometry.location


                }));

                if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }
            });
            map.fitBounds(bounds);
        });
    }

</script>
<!--User Profile image submit ajax-->
<script>
    $(document).ready(function() {
        $('#inputfile').change(function(){
            var file_data = $('#inputfile').prop('files')[0];
            var form_data = new FormData();
            form_data.append('file', file_data);
            $.ajax({
                url: 'User/Image',
                type: "POST",
                data:  form_data,
                contentType: false,
                cache: false,
                processData:false,
                success: function(data){
                    console.log(data);
                }
            });
        });
    });
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDpBHXBCPjgNr31q7dVBRLOhPsy2jKLAjE&libraries=places&callback=initAutocomplete"
        async defer></script>
</body>
</html>



<!-- Modal sign-in-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content col-sm-12">
            <div class="container">
                <div id="login-box">
                    {{Form::open(['route'=>'clientLogin', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])}}
                    <div class="logo">
                        <img src="{{asset('/')}}/front-end/img/icons.png" height="100" width="100" class="img img-responsive img-circle center-block"/>
                        <h1 class="logo-caption"><span class="tweak">L</span>ogin</h1>
                    </div><!-- /.logo -->
                    <div class="controls">
                        <h3 class="text-center text-danger">{{Session::get('message')}}</h3><br>
                        <input type="email" name="email" placeholder="Email" value="{{Session::get('clienEmail') ? $checklogin->email :''}}" class="form-control" />
                        <span class="text-danger">{{$errors->has('email') ? $errors->first('email') : ''}}</span>
                        <input type="password" name="password" placeholder="Password" value="{{Session::get('clienEmail') ? $checklogin->password :''}}" class="form-control" />
                        <span class="text-danger">{{$errors->has('password') ? $errors->first('password') : ''}}</span>
                        <button type="submit" name="btn" class="btn btn-default btn-block btn-custom">Login</button>
                        <br><br><br>
                    </div><!-- /.controls -->
                    {{Form::close()}}
                </div><!-- /#login-box -->
            </div><!-- /.container -->
        </div>
    </div>
</div>
<!--modal sign-in end-->

<!-- Modal sign-up-->
<div class="modal fade" id="myModalTwo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content col-sm-12">
            <div class="container">
                <div id="login-box">

                    <div class="logo">
                        <img src="{{asset('/')}}/front-end/img/icons.png" height="100" width="100" class="img img-responsive img-circle center-block"/>
                        <h1 class="logo-caption"><span class="tweak">S</span>ignUp</h1>
                    </div><!-- /.logo -->
                    {{Form::open(['route'=>'client-signup', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])}}
                    <div class="controls">
                        <label>Name</label>
                        <input type="text" name="name" placeholder="Your-Name" class="form-control" />
                        <span class="text-danger">{{$errors->has('name') ? $errors->first('name') : ''}}</span>
                        <br>
                        <label>Email</label>
                        <input type="email" name="email" placeholder="Email" class="form-control" />
                        <span class="text-danger">{{$errors->has('email') ? $errors->first('email') : ''}}</span>
                        <br>
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Password" class="form-control" />
                        <label>Confirm-Password</label>
                        <input type="password" id="password-confirm"  placeholder="Retype-Password" class="form-control" name="password_confirmation"/>
                        <span class="text-danger">{{$errors->has('password') ? $errors->first('password') : ''}}</span>

                        <button type="submit" name="btn" class="btn btn-default btn-block btn-custom">SignUp</button>
                    </div><!-- /.controls -->
                    {{Form::close()}}
                </div><!-- /#login-box -->
            </div><!-- /.container -->
        </div>
    </div>
</div>
<!--Modal sign up end-->

<!-- Button trigger modal -->


<!-- Modal terms and condition -->
<div class="modal fade" id="myModalThree" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Courier Bd Terms & Condition</h4>
            </div>
            <div class="modal-body">
                <p>
                    Overflowing text to show scroll behavior
                    Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.

                    Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

                    Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.

                    Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.

                    Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

                    Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.

                    Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.

                    Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

                    Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>

            </div>
        </div>
    </div>
</div>