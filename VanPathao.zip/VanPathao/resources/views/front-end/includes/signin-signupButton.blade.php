<div class="right-header">

    <ul class="list-inline pull-right">
        <li class="box">
            <a href=""  class="btn btn-grey btn-sm text-uppercase" data-toggle="modal" data-target="#myModalTwo"><i class="fa fa-user pr-10"> </i>  Sign Up
            </a>
        </li>
        <li class="box">
            <a href="" class="btn btn-grey btn-sm text-uppercase" data-toggle="modal" data-target="#myModal"><i class="fa fa-lock pr-10"> </i>
                Sign in
            </a>
        </li>
    </ul>

</div>