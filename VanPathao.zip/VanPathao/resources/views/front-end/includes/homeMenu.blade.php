
<div class="background-side"><!-- background-side start  -->
    <nav class="second-navbar"><!-- second-navbar start  -->
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" id="title" href="{{route('/')}}"><i class="fa fa-truck" aria-hidden="true"></i>Courier BD</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="{{ request()->is('/') ? 'active' : '' }}" href="{{route('/')}}">Home</a>
                    </li>
                    <li>
                        <a class="{{ request()->is('companies') ? 'active' : '' }}" href="{{route('companies')}}">Companies</a>
                    </li>
                    <li>
                        <a class="{{ request()->is('order') ? 'active' : '' }}" href="{{route('order')}}">Order</a>
                    </li>
                    <li>
                        <a class="{{ request()->is('about') ? 'active' : '' }}" href="{{route('about')}}">About Us</a>
                    </li>
                    <li>
                        <a class="{{ request()->is('price') ? 'active' : '' }}" href="{{route('price')}}">Price</a>
                    </li>
                    <li>
                        <a class="{{ request()->is('contact') ? 'active' : '' }}" href="{{route('contact')}}">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav><!-- second-navbar end  -->

    <h3 class="trust">Trusted For courier Services</h3>
    <h1 class="send">Send Your Goods To The <br> Courier Companies By sitting at home</h1>
    <div class="track-form">
        <h3>Track your product</h3>
        <h1 class="text-center text-danger">{{Session::get('message')}}</h1>
        <p class="text-center text-success" style="font-size: 25px;">{{Session::get('myorderStatus')}}</p>
        <p class="text-center text-success" style="font-size: 25px;">{{Session::get('myShipmentStatus')}}</p>

        <form class="form-inline" method="POST" action="{{route('orderTrack')}}" align="center">
            {{csrf_field()}}
        {{--<form class="form-inline" align="center" action="{{ route('orderTrack') }}" method="POST" enctype="multipart/form-data">--}}
            {{--{{Form::open(['route'=>'orderTrack','class'=>'form-inline','method'=>'post','enctype'=>'multipart/form-data'])}}--}}

            <div class="input-group mb-2 mr-sm-2 mb-sm-0" >
                <input name="orderId" type="text" class="form-control" id="inlineFormInputGroup" placeholder="ORDER ID" pattern="[1-9][0-9]*|0" required>
            </div>

            {{--<div class="input-group mb-2 mr-sm-2 mb-sm-0">--}}
                {{--<input type="text" name="phone" class="form-control" id="inlineFormInput" placeholder="PHONE" pattern="[01]{2}[0-9]{9}" required>--}}
            {{--</div>--}}

            <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                <input type="submit" class="form-control" id="inlineFormSubmit" value="TRACK">
            </div>
            {{--{{Form::close()}}--}}

        </form>


    </div>
</div><!-- background-side end  -->