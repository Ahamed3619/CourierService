@if(Session::get('clienEmail'))


    <ul class="list-inline" id="profiles" >
        <li class="dropdown" >
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i>Welcome {{$checklogin->name}} <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user" >
                <li><a href="{{route('userProfile')}}"><i class="fa fa-user fa-fw"></i> Profile</a>
                </li>
                <li><a href="{{route('changePassword')}}"><i class="fa fa-gear fa-fw"></i> Settings</a>
                </li>
                <li class="divider"></li>
                <li><a href="{{ route('clientLogout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">

                        <i class="fa fa-sign-out fa-fw"></i> Logout

                    </a>
                    <form id="logout-form" action="{{ route('clientLogout') }}" method="POST" style="display: none;">
                        {{ csrf_field() }}
                    </form>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
    </ul>




@else
    @include('front-end.includes.signin-signupButton')
@endif



