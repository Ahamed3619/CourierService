<div class="order" xmlns="http://www.w3.org/1999/html">
    <div class="container">
        <h2 class="order-title"><hr><br> Make a <strong>Order</strong> Easily </h2><br>
        <hr><br><br>
        <div  class="col-lg-6 col-md-6 col-sm-12" id="order-img">
            <img src="{{asset('/')}}/front-end/img/man.png">
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12" id="order-box">
            <h1 class="text-center text-danger">{{Session::get('message')}}</h1>
            <h3>Send Your Goods To The Popular Courier Companies By Sitting At Home.<span style="color: red;font-weight: bold;">Sign-In*</span> First & Fill The <strong>Order-Form</strong> Below.Our Member Will Arrive Fast To You.</h3>
            <!--Form Start-->
            {{Form::open(['route'=>'userOrder','method'=>'POST','class'=>'form-section','enctype'=>'multipart/form-data'])}}



                <span style="font-size:17px;font-weight:bold;">Sender<span style="color:red;font-size:20px">*</span></span><hr>
                <input type="text" name="senderName" pattern="[a-zA-Z]{3,20}[a-zA-Z\s]*" required placeholder="Sender-Name" value="{{Session::get('clienEmail') ? $checklogin->name :''}}" title="Sender-Name should only contain letters">

                <input type="text" required pattern="[01]{2}[0-9]{9}" name="senderPhone" placeholder="Sender-Phone (01826996528)" value="{{Session::get('clienEmail') ? $checklogin->phone :''}}" title="Enter Valid Phone Number"/>
                <input type="address" name="senderAddress" required pattern="[a-zA-Z0-9][a-zA-Z0-9,/.:-\s]*" id="address" placeholder="Home Address (166/19/3,A,Adorsapara,Madertek)" value="{{Session::get('clienEmail') ? $checklogin->address :''}}" title="Please enter address correctly">
                <div class="selecting">
                    <div class="select-left">
                        <select  name="senderDivision" id="meal" required onChange="changecat(this.value);">
                            <option  disabled selected>DIVISION</option>
                            <option value="DHAKA">DHAKA</option>
                            <option value="CHITTAGONG">CHITTAGONG</option>
                            <option value="BARISAL">BARISAL</option>
                            <option value="RAJSHAHI">RAJSHAHI</option>
                            <option value="SYLHET">SYLHET</option>
                            <option value="KHULNA">KHULNA</option>
                            <option value="MYMENSINGH">MYMENSINGH</option>
                            <option value="RANGPUR">RANGPUR</option>
                        </select>
                    </div>
                    <div class="select-right">
                        <select  name="senderCity" id="category" value="" required>
                            <option  disabled selected>CITY</option>
                        </select>
                    </div>
                </div>

                <span style="font-size:17px;font-weight:bold">Receiver<span style="color:red;font-size:20px">*</span></span>
                <hr>
                <input type="text" name="receiverName" pattern="[a-zA-Z]{3,20}[a-zA-Z\s]*" placeholder="Receiver-Name" title="Receiver-Name should only contain letters" required>

                <!--Email if needed
                <span style="font-size:17px;font-weight:bold">Sender Email</span>
                <input type="email" name="senderemail"  title="Enter Valid Email e.g:example@mail.com" placeholder="Sender-Email">



                <span style="font-size:17px;font-weight:bold">Receiver Email</span>
                <input type="email" name="receiveremail"  title="Enter Valid Email e.g:example@gmail.com" placeholder="Receiver-Email">

                -->
                <input type="text" required pattern="[01]{2}[0-9]{9}" name="receiverPhone" placeholder="Receiever-Phone (01826996528)" title="Enter Valid Phone Number e.g:01756576638"/>

                <input type="text" name="receiverAddress" required pattern="[a-zA-Z0-9][a-zA-Z0-9,/.:-\s]*" id="address" placeholder="Home-Address (166/19/3,A,Adorsapara,Madertek) " title="Please enter address correctly e.g:166/19/3A,Madertek,Sabujbagh,Dhaka,Bangladesh">

                <div class="selecting">
                    <div class="select-left">
                        <select  name="receiverDivision" id="meals" required onChange="changecats(this.value);">
                            <option value="" disabled selected>DIVISION</option>
                            <option value="Dhaka">DHAKA</option>
                            <option value="Chittagong">CHITTAGONG</option>
                            <option value="Barisal">BARISAL</option>
                            <option value="Rajshahi">RAJSHAHI</option>
                            <option value="Sylhet">SYLHET</option>
                            <option value="Khulna">KHULNA</option>
                            <option value="Mymensingh">MYMENSINGH</option>
                            <option value="Rangpur">RANGPUR</option>
                        </select>
                    </div>
                    <div class="select-right">
                        <select  name="receiverCity" id="categories" required>
                            <option value= disabled selected>CITY</option>
                        </select>
                    </div>
                </div>



                <span style="font-size:17px;font-weight:bold">Product Name/Type<span style="color:red;font-size:20px">*</span></span>
                <input type="text" name="productName" required pattern="[a-zA-Z][a-zA-Z\s]*" placeholder="Enter Your Product Name/type" title="Please enter Your product name e.g:Smartphone">




                <span style="font-size:17px;font-weight:bold">Product Quantity<span style="color:red;font-size:20px">*</span></span>
                <select name="orderQuantity" required>
                    <option value=""  disabled selected>Select Quantity of Your Goods</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>

                </select>




                <span style="font-size:17px;font-weight:bold">Select A Courier Company<span style="color:red;font-size:20px">*</span></span>
                <select name="orderCompany"required>
                    <option value=""  disabled selected>Choose A Company</option>
                    @foreach($myCompany as $companies)
                    <option value="{{$companies->company_name}}">{{$companies->company_name}}</option>
                    @endforeach
                </select>



                <input type="checkbox" name="conditionAgree" value="yes" required>
                <span>I Agree To The <a href="#" data-toggle="modal" data-target="#myModalThree" class="all-conditions">Terms &amp; Conditions</a></span>

                <input type="submit" value="SUBMIT">



            {{Form::close()}}

            <!--Form End-->
        </div>
    </div>
</div>
<!-- Order Div End -->