<!-- All Courier Companies Start -->

<div class="courier-companies">
    <div class="container">
        <h2 class="Companies-title"><hr><br> <strong>Associated</strong> Companies </h2><br>
        <hr><br><br>
        @foreach($myCompany as $companies)
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="thumbnail">
                    <a class="first-item" href="{{route('search')}}">
                        <img src="{{asset($companies->company_image)}}"alt="Companies">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content ">
                                <div class="first-content">
                                    Find Branches
                                </div>
                            </div>
                        </div>
                    </a>
                    <div class="caption">
                        <a href="{{route('search')}}" class="company-name"><h4><strong>{{$companies->company_name}}</strong></h4></a>
                        <p>{!!$companies->description  !!}</p>

                        <p class="pull-right text-danger">7 Reviews</p>
                        <p class="text-success">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half"></i>
                        </p>
                    </div>
                </div>
            </div>
        @endforeach


    </div>
</div>

<!-- All Courier Companies End -->

<!-- Order Div Start -->

@include('front-end.includes.orderContent')

<!-- About-us Div start -->
<div class="about-us">
    <div class="container">
        <h2 class="about-title"><hr><br> ABOUT-<strong>US</strong> </h2><br>
        <hr><br>
        <p class="about-description">
            Courier BD is a Bangladeshi Company.In Bangladesh most of the people face different types of problem to get courier services.Courier BD arranged the program to solve these problem.Courier BD Send your Products from your home to popular courier companies.So you can Send your products to the courier companies by sitting at home.Stay tuned with us to get best & fastest serivecs in courier.Thank You.
        </p>
        <div class="col-lg-3 col-sm-6 col-md-6">
            <div id="about-order">
                <div class="numbering">
                    <h1>1.</h1>
                </div>
                <div class="details">
                    <h1>Order</h1><br>
                    <p>Courier BD Takes Order From you & send Your Products from your home to Courier Companies.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-md-6">
            <div id="about-wait">
                <div class="numbering">
                    <h1>2.</h1>
                </div>
                <div class="details">
                    <h1>Wait</h1><br>
                    <p>You can order us in the order section.Wait for sometime our member will arrive your home early.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-md-6">
            <div id="about-delivery">
                <div class="numbering">
                    <h1>3.</h1>
                </div>
                <div class="details">
                    <h1>Delivery</h1><br>
                    <p>Our Member Will take your courier products from your home & Deliver it to your Desire courier company.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-md-6">
            <div id="about-worldwide">
                <div class="numbering">
                    <h1>4.</h1>
                </div>
                <div class="details">
                    <h1>Worldwide</h1><br>
                    <p>You can order us to send your Courier Products from your home to other Countries.order us by call.</p>
                </div>
            </div>
        </div>
    </div>
</div><!--About us div End-->



<!-- price div start -->

<div class="price">
    <div class="container">
        <h2 class="price-title"><hr><br> Pricing <strong>&</strong> Plan </h2><br>
        <hr><br><br>
        <div class="col-lg-4 col-sm-12 col-md-4">
            <div class="thumbnail" id="hover-border">
                <h1 class="item-one">
                    250 TK .
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content ">
                            <div class="content-one">
                                <p>ENTIRE DHAKA CITY<p>
                            </div>
                        </div>
                    </div>
                </h1>
                <div class="caption">
                    <h3><strong>Dhaka</strong> to <strong>Dhaka</strong> </h3>
                    <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                    <h5>Duration: <span style="color:gray"> 2 Days</span></h5>
                    <h5>Support: <span style="color:gray"> Yes</span></h5>
                    <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-12 col-md-4">
            <div class="thumbnail" id="thumb-border">
                <h1 class="item-one">
                    350 TK .
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content ">
                            <div class="content-one">
                                <p>OUTSIDE OF DHAKA<p>
                            </div>
                        </div>
                    </div>
                </h1>
                <div class="caption">
                    <h3><strong>Dhaka</strong> to <strong>Other's</strong> </h3>
                    <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                    <h5>Duration: <span style="color:gray"> 4 Days</span></h5>
                    <h5>Support: <span style="color:gray"> Yes</span></h5>
                    <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                </div>
            </div>
        </div>


        <div class="col-lg-4 col-sm-12 col-md-4">
            <div class="thumbnail" id="hover-border">
                <h1 class="item-one">
                    450 TK .
                    <div class="portfolio-box-caption">
                        <div class="portfolio-box-caption-content ">
                            <div class="content-one">
                                <p>OUTSIDE OF BANGLADESH<p>
                            </div>
                        </div>
                    </div>
                </h1>
                <div class="caption">
                    <h3><strong>Dhaka</strong> to <strong>Worldwide</strong> </h3>
                    <h5>Product Weight: <span style="color:gray">  < 3kg</span></h5>
                    <h5>Duration: <span style="color:gray"> 7 Days</span></h5>
                    <h5>Support: <span style="color:gray"> Yes</span></h5>
                    <a href="{{route('order')}}" class="order-link"><p class="order-button">order now</p> </a>
                </div>
            </div>
        </div>


    </div>
</div><!--Price div End-->

<!-- Team div start -->

<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox" id="team">
        <div class="item active">
            <h2 class="team-title">Our-<strong>Team</strong>  </h2>

            <img src="{{asset('/')}}/front-end/img/tanvir.jpg" class="img-responsive img-circle"  alt="...">

            <div class="carousel-caption">
                <p>It is a long established fact that a reader will be distracted by the readable content<br> of a page when looking at its layout.</p>
                <h3>MD. Tanvir</h3>
            </div>
        </div>

        <div class="item">
            <h2 class="team-title">Our-<strong>Team</strong> </h2>

            <img src="{{asset('/')}}/front-end/img/habib.jpg"  class="img-responsive img-circle"  alt="...">

            <div class="carousel-caption">
                <p>It is a long established fact that a reader will be distracted by the readable content<br> of a page when looking at its layout.</p>
                <h3>H.R Habib</h3>
            </div>
        </div>

    </div>

    <!-- Controls -->
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>

</div><!--Team div End-->


@include('front-end.includes.contactContent')