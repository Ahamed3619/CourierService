@extends('front-end.master')

@section('signinSignup')
    @include('front-end.includes.loginChecker')
@endsection

@section('menu')
    @include('front-end.includes.orderMenu')
@endsection

@section('title')

   ORDER
@endsection

@section('body')
    <!-- Order Div Start -->
    @include('front-end.includes.orderContent')

    <!-- Order Div End -->

@endsection