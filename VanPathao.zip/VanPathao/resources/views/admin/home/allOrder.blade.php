@extends('admin.home.master')
@section('title')
    All Order
@endsection

@section('body')
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> All Order</h1>
                </div>
                <div class="panel-body" style="padding: 0px; margin:0px;">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table border="1px solid #F5F5F5" height="100%" width="100%">
                        <tr class="bg-primary">
                            <th>OrderID</th>
                            <th>Sender</th>
                            {{--<th>Description</th>--}}
                            <th>Receiver</th>
                            <th>Product</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                        @foreach($allOrder as $myOrder)
                            <tr>
                                <td>{{$myOrder->id}}</td>
                                <td>{{$myOrder->senderName}}</td>
                                <td>{{$myOrder->receiverName}}</td>
                                <td>{{$myOrder->productName}}</td>
                                <td>{{$myOrder->orderStatus}}</td>
                                <td>{{$myOrder->created_at->format('Y-m-d') }}</td>
                                {{--<td>{{$myCompany->publication_status==1 ? 'published':'Unpublished'}}</td>--}}
                                <td>
                                    @if($myOrder->orderStatus=='Pending')
                                        <a href="{{route('order_confirm',['id'=>$myOrder->id])}}" class="btn btn-warning btn-xs" title="Make Order Confirm">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    @else
                                        <a href="{{route('order_pending',['id'=>$myOrder->id])}}" class="btn btn-info btn-xs" title="Make Order Pending">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    @endif
                                    <a href="{{route('view_order',['id'=>$myOrder->id])}}" class="btn btn-primary btn-xs" title="View Order Details">
                                        <span class="glyphicon glyphicon-zoom-in"></span>
                                    </a>
                                    <a href="{{route('view_order_invoice',['id'=>$myOrder->id])}}" class="btn btn-success btn-xs" title="Order Invoice">
                                        <span class="glyphicon glyphicon-zoom-out"></span>
                                    </a>
                                    <a href="{{route('edit_order',['id'=>$myOrder->id])}}" class="btn btn-info btn-xs" title="Shipment Status">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>

                                    <a href="{{route('download_order',['id'=>$myOrder->id])}}" class="btn btn-success btn-xs" title="Download Invoice">
                                        <span class="glyphicon glyphicon-download"></span>
                                    </a>
                                    <a href="{{route('delete_order',['id'=>$myOrder->id])}}" class="btn btn-danger btn-xs" title="Delete Order" onclick="return confirm ('Are You Sure to Delete')">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>

    </div>

@endsection