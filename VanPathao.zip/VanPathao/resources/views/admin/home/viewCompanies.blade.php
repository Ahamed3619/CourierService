@extends('admin.home.master')
@section('title')
    Manage Courier Companies
@endsection

@section('body')
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Manage Companies</h1>
                </div>
                <div class="panel-body" style="padding: 0px; margin:0px;">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table border="1px solid #F5F5F5" height="100%" width="100%">
                        <tr class="bg-primary">
                            <th>SL</th>
                            <th>Name</th>
                            {{--<th>Description</th>--}}
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        @php($i=1)
                        @foreach($allCompanies as $myCompany)
                            <tr>
                                <td>{{$i++}}</td>
                                <td>{{$myCompany->company_name}}</td>
                                {{--<td>{!! $myCompany->description !!}</td>--}}
                                <td><img src="{{ asset($myCompany->company_image) }}" height="100px" width="150px" alt=""></td>
                                <td>{{$myCompany->publication_status==1 ? 'published':'Unpublished'}}</td>
                                <td>
                                    @if($myCompany->publication_status==1)
                                        <a href="{{route('company_unpublished',['id'=>$myCompany->id])}}" class="btn btn-info btn-xs">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    @else
                                        <a href="{{route('company_published',['id'=>$myCompany->id])}}" class="btn btn-warning btn-xs">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    @endif
                                    <a href="{{route('edit_company',['id'=>$myCompany->id])}}" class="btn btn-success btn-xs">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a href="{{route('delete_company',['id'=>$myCompany->id])}}" class="btn btn-danger btn-xs" onclick="return confirm ('Are You Sure to Delete')">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>

    </div>

@endsection