@extends('admin.home.master')
@section('title')
    View Details
@endsection

@section('body')
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Order Details </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-info">
                            <th>Order ID</th>
                            <td>{{$orderPrice->orderId}}</td>
                        </tr>
                        <tr>
                            <th>Order Date</th>
                            <td>{{ $clientOrder->created_at->format('d M Y - H:i:s') }}</td>
                        </tr>
                        <tr>
                            <th>Order Status</th>
                            <td>{{ $clientOrder->orderStatus}}</td>
                        </tr>

                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Sender Details </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-danger">
                            <th>Sender Name</th>
                            <td>{{$clientOrder->senderName}}</td>
                        </tr>
                        <tr>
                            <th>Sender Phone</th>
                            <td>{{$clientOrder->senderPhone}}</td>
                        </tr>
                        <tr>
                            <th>Sender Email</th>
                            <td>{{$clientOrder->senderEmail}}</td>
                        </tr>
                        <tr>
                            <th>Sende Address</th>
                            <td>{{$clientOrder->senderAddress}}</td>
                        </tr>
                        <tr>
                            <th>Sende Division</th>
                            <td>{{$clientOrder->senderDivision}}</td>
                        </tr>
                        <tr>
                            <th>Sende City</th>
                            <td>{{$clientOrder->senderCity}}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Receiver Details </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-success">
                            <th>Receiver Name</th>
                            <td>{{$clientOrder->receiverName}}</td>
                        </tr>
                        <tr>
                            <th>Receiver Phone</th>
                            <td>{{$clientOrder->receiverPhone}}</td>
                        </tr>
                        <tr>
                            <th>Receiver Address</th>
                            <td>{{$clientOrder->receiverAddress}}</td>
                        </tr>
                        <tr>
                            <th>Receiver Division</th>
                            <td>{{$clientOrder->receiverDivision}}</td>
                        </tr>
                        <tr>
                            <th>Receiver City</th>
                            <td>{{$clientOrder->receiverCity}}</td>
                        </tr>


                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Product Details </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-primary">
                            <th>Product Name</th>
                            <td>{{$clientOrder->productName}}</td>
                        </tr>
                        <tr>
                            <th>Product Quantity</th>
                            <td>{{$clientOrder->orderQuantity}}</td>
                        </tr>
                        <tr>
                            <th>Product Weight</th>
                            <td>{{$orderPrice->productWeight}} K.G</td>
                        </tr>
                        <tr>
                            <th>Product Height</th>
                            <td>{{$orderPrice->productHeight}} Inches</td>
                        </tr>
                        <tr>
                            <th>Product Width</th>
                            <td>{{$orderPrice->productWidth}} Inches</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Price & Payment </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-warning">
                            <th>Total Price</th>
                            <td>{{$orderPrice->TotalPrice}} TK /-</td>
                        </tr>
                        <tr>
                            <th>Payment Type</th>
                            <td>{{$orderPrice->payMethod}}</td>
                        </tr>
                        <tr>
                            <th>Shipment Status</th>
                            <td>{{$orderPrice->ShipmentStatus}}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Company & Agreement </h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    <table class="table table-bordered">
                        <tr class="bg-danger">
                            <th>Courier Company</th>
                            <td>{{$clientOrder->orderCompany}}</td>
                        </tr>
                        <tr>
                            <th>Terms & Condition Agree</th>
                            <td>{{$clientOrder->conditionAgree}}</td>
                        </tr>

                    </table>
                </div>
            </div>
        </div>

    </div>

@endsection