<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Order Invoice</title>
    <style>

        header {
            padding: 10px 0;
            margin-bottom: 30px;
        }

        #logo {
            text-align: center;
            margin-bottom: 10px;
        }

        #logo img {

            padding: 10px;
        }

        h1 {
            border-top: 1px solid  #5D6975;
            border-bottom: 1px solid  #5D6975;
            color: #5D6975;
            font-size: 2.4em;
            line-height: 1.4em;
            font-weight: normal;
            text-align: center;
            margin: 0 0 20px 0;
            background: url(dimension.png);
        }

        #project {
            float: left;
        }

        #project span {
            color: #5D6975;
            text-align: right;
            width: 52px;
            margin-right: 10px;
            display: inline-block;
            font-size: 0.8em;
        }

        #company {
            float: right;
            text-align: right;
        }

        #project div,
        #company div {
            white-space: nowrap;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            margin-bottom: 20px;
        }

        table tr:nth-child(2n-1) td {
            background: #F5F5F5;
        }

        table th,
        table td {
            text-align: center;
        }

        table th {
            padding: 5px 20px;
            color: #5D6975;
            border-bottom: 1px solid #C1CED9;
            white-space: nowrap;
            font-weight: normal;
        }

        table .service,
        table .desc {
            text-align: left;
        }

        table td {
            padding: 20px;
            text-align: right;
        }

        table td.service,
        table td.desc {
            vertical-align: top;
        }

        table td.unit,
        table td.qty,
        table td.total {
            font-size: 1.2em;
        }

        table td.grand {
            border-top: 1px solid #5D6975;;
        }

        #notices .notice {
            color: #5D6975;
            font-size: 1.2em;
        }

        .wrapper{
            width: 100%;
        }
    </style>

</head>
<body>
 <div class="wrapper">

        <div id="logo">
            <img src="{{asset('/')}}/admin/dist/css/logo.jpg" class="img-circle">
        </div>
        <h1>ORDER INVOICE </h1>
        <div style="float: right; width: 50%;text-align: right">
            <h3 class="text-center bg-success" >Company Info</h3>
            <div>Name : Courier BD</div>
            <div>Phone : +55 4377-634-7071</div>
            <div>Email : service@courierbd.com</div>
            <div>Address : Dhanmondi, Sukrabad, Dhaka-1200</div>
        </div>
        <div style="float: left; width: 50%; text-align: left;">
            <h3 class="text-center bg-success" >Billing Info</h3>
            <div>Sender : {{$clientOrder->senderName}}</div>
            <div>Phone :  +880{{$clientOrder->senderPhone}}</div>
            <div>Phone :  {{$clientOrder->senderEmail}}</div>
            <div>Address : {{$clientOrder->senderAddress}}, {{$clientOrder->senderCity}}, {{$clientOrder->senderDivision}}</div>

        </div>


    <div style="padding-top: 200px;">

        <h3 style="text-align: center;" >Shipment Info</h3>
        <div style="text-align: center">Receiver : {{$clientOrder->receiverName}}</div>
        <div style="text-align: center">Phone :  +880{{$clientOrder->receiverPhone}}</div>
        <div style="text-align: center">Address : {{$clientOrder->receiverAddress}}, {{$clientOrder->receiverCity}}, {{$clientOrder->receiverDivision}}</div>
    </div>
    <br>
    <main>
        <h3 style=" text-align: center;" >Order Info</h3>
        <br><br>
        <table>
            <thead>
            <tr>
                <th class="service">ID</th>
                <th class="service">DATE</th>
                <th class="desc">NAME</th>
                <th class="desc">WEIGHT</th>
                <th class="desc">HEIGHT</th>
                <th class="desc">WIDTH</th>
                <th class="desc">QTY</th>
                <th class="desc">PRICE</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td class="desc">{{$orderPrice->orderId}}</td>
                <td class="desc">{{ $clientOrder->created_at->format('d M Y') }}</td>
                <td class="desc">{{$clientOrder->productName}}</td>
                <td class="desc">{{$orderPrice->productWeight}} K.G</td>
                <td class="desc">{{$orderPrice->productHeight}} Inches</td>
                <td class="desc">{{$orderPrice->productWidth}} Inches</td>
                <td class="desc">{{$clientOrder->orderQuantity}}</td>
                <td class="desc">{{$orderPrice->TotalPrice}} TK</td>
            </tr>
            <tr>
                <td colspan="7" class="grand total">GRAND TOTAL</td>
                <td class="desc">{{$orderPrice->TotalPrice}} TK</td>
            </tr>
            </tbody>
        </table>
    </main>
 </div>
</body>
</html>