@extends('admin.home.master')
@section('title')
    Add a New Courier
@endsection

@section('body')

    <div class="row" xmlns="http://www.w3.org/1999/html">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="text-center text-success"> Enter Shipment Status</h1>
                </div>
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    {{Form::open(['route'=>'shipment-status', 'method'=>'post', 'class'=>'form-horizontal','enctype'=>'multipart/form-data'])}}

                    <div class="form-group">
                        <label class="control-label col-md-4">Order ID</label>
                        <div class="col-md-8">
                            <input type="text" name="orderId" class="form-control" value="{{$orderId}}">
                            <span class="text-danger">{{$errors->has('orderId') ? $errors->first('orderId') : ''}}</span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Shipment Status</label>
                        <div class="col-md-8">
                            <input type="text" name="ShipmentStatus" class="form-control">
                            <span class="text-danger">{{$errors->has('ShipmentStatus') ? $errors->first('ShipmentStatus') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save">
                        </div>
                    </div>
                    {{Form::close()}}
                </div>
            </div>
        </div>

    </div>

@endsection